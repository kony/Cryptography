function p2kwiet341880914251_segNavigation_onRowClick_seq0(eventobject, sectionNumber, rowNumber) {
    return segClickEvent.call(this, eventobject, sectionNumber, rowNumber);
}