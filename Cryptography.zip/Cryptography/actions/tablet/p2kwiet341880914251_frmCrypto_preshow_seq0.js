function p2kwiet341880914251_frmCrypto_preshow_seq0(eventobject, neworientation) {
    return frmCryptoTabPreShow.call(this);
}