function p2kwiet341880914267_btnHome_onClick_seq0(eventobject) {
    return navigateToFrmCrypto.call(this);
}