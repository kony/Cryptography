function p2kwiet341880914251_button1930040990150784_onClick_seq0(eventobject) {
    return createHashMD2.call(this);
}