function p2kwiet341880914251_frmCrypto_preshow_seq0(eventobject, neworientation) {
    frmCryptoTabPreShow.call(this);
};

function p2kwiet341880914251_segNavigation_onRowClick_seq0(eventobject, sectionNumber, rowNumber) {
    segClickEvent.call(this, eventobject, sectionNumber, rowNumber);
};

function p2kwiet341880914251_button1930040990147649_onClick_seq0(eventobject) {
    Encrypt.call(this);
};

function p2kwiet341880914251_button1930040990147720_onClick_seq0(eventobject) {
    decrypt.call(this);
};

function p2kwiet341880914251_button1930040990150784_onClick_seq0(eventobject) {
    createHashMD2.call(this);
};

function p2kwiet341880914251_button1930040990151288_onClick_seq0(eventobject) {
    createHashMD4.call(this);
};

function p2kwiet341880914251_button1930040990151315_onClick_seq0(eventobject) {
    createHashMD5.call(this);
};

function p2kwiet341880914267_btnHome_onClick_seq0(eventobject) {
    navigateToFrmCrypto.call(this);
};