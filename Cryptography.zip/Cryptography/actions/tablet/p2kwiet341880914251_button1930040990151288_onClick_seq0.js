function p2kwiet341880914251_button1930040990151288_onClick_seq0(eventobject) {
    return createHashMD4.call(this);
}