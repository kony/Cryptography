
function p2kwiet341880914172_btnContinue_onClick_seq0(eventobject){

navigateToFrmCrypto.call(this);

};


function p2kwiet341880914201_frmCrypto_preshow_seq0(eventobject,    neworientation){

frmCryptoPreShow.call(this);

};


function p2kwiet341880914201_btnEncrypt_onClick_seq0(eventobject){

Encrypt.call(this);

};


function p2kwiet341880914201_btnDecrypt_onClick_seq0(eventobject){

decrypt.call(this);

};


function p2kwiet341880914201_btnMd2_onClick_seq0(eventobject){

createHashMD2.call(this);

};


function p2kwiet341880914201_btnMd4_onClick_seq0(eventobject){

createHashMD4.call(this);

};


function p2kwiet341880914201_btnMd5_onClick_seq0(eventobject){

createHashMD5.call(this);

};

