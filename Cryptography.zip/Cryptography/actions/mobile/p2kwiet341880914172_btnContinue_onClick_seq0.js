function p2kwiet341880914172_btnContinue_onClick_seq0(eventobject) {
    return navigateToFrmCrypto.call(this);
}