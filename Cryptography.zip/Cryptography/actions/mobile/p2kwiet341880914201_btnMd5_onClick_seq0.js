function p2kwiet341880914201_btnMd5_onClick_seq0(eventobject) {
    return createHashMD5.call(this);
}