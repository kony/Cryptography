function p2kwiet341880914201_btnMd4_onClick_seq0(eventobject) {
    return createHashMD4.call(this);
}