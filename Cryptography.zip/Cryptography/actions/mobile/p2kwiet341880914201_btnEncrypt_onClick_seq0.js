function p2kwiet341880914201_btnEncrypt_onClick_seq0(eventobject) {
    return Encrypt.call(this);
}