function p2kwiet341880914201_frmCrypto_preshow_seq0(eventobject, neworientation) {
    return frmCryptoPreShow.call(this);
}