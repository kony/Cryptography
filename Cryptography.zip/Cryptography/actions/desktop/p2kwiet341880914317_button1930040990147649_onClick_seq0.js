function p2kwiet341880914317_button1930040990147649_onClick_seq0(eventobject) {
    return Encrypt.call(this);
}