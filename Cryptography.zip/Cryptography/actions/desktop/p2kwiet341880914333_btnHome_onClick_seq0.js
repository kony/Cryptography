function p2kwiet341880914333_btnHome_onClick_seq0(eventobject) {
    return navigateToFrmCrypto.call(this);
}